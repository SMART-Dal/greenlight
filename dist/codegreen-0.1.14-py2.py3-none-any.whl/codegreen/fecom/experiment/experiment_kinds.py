from enum import Enum

class ExperimentKinds(Enum):
    METHOD_LEVEL = "method-level"
    PROJECT_LEVEL = "project-level"
    DATA_SIZE = "data-size"