# FECoM package
Configure all settings in `/measurement/measurement_config.py` and `/patching/patching_config.py`. Otherwise, you can find
- experiment running, data analysis and plotting modules in `/experiment`
- the patching modules in `/patching`
- the energy measurement modules in `/measurement`

In `/measurement` you will also find `start_measurement.py`, the module you need to run to start the energy measurement tools.